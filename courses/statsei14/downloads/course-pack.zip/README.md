# Notebook course pack
Extract this pack and open notebooks/workshop.ipynb from its folder, or upload the notebook in Colab and upload this ZIP when prompted.
workshop-solved.ipynb contains prepared outputs. The separate transformer-demo.ipynb supports the closing comparison, and transformer-demo-solved.ipynb contains its executed outputs. Use the full course-pack.zip for this demo because it includes cached features and the frozen pilot results. results/reference-run records the original single-seed LSTM/score experiment. results/transformer-pilot records the frozen three-seed comparison. results/transformer-demo-run records the separate demo execution. Keep these evidence sets distinct.
For a local Python environment: python -m pip install -r requirements.txt; then open the notebook with your Jupyter editor.
This pack contains data, configuration, notebooks, results, the instructor guide, homework and references. Full Quarto sources and build scripts are in the separate manual-upload release.
The experiment uses a revised retrospective catalogue; historical as-of availability and actual Colab execution are not certified by the local run.
