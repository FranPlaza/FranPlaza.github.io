
The live session combines a guided LSTM exercise with a separate, tested Transformer comparison. This follow-up offers a paper-and-evidence discussion requiring no coding and a bounded extension of the executable demo. Both continue the same question: **what can a flexible model learn from a particular representation, and how would we know?** Use the laboratory week to work at a suitable pace.

[Return to the practical](https://franplaza.github.io/statsei14-deep-learning/practical.html) · [References and source links](https://franplaza.github.io/statsei14-deep-learning/references.html)

## Level 1 — Read the task before the architecture

**Suggested time: 45–60 minutes. No training required.**

Begin with the [prepared Transformer comparison](notebooks/transformer-demo-solved.ipynb). State one observation supported by its scores and one possible explanation that those scores alone cannot establish. Then compare the tutorial with two papers: one on earthquake forecasting and one on another seismic learning task. Suggested choices are RECAST or Farfán et al. (2025) for forecasting, and ConvNetQuake or Delgado et al. (2025) for detection/classification. Follow the links on the [references page](https://franplaza.github.io/statsei14-deep-learning/references.html).

1. Write the scientific question in one sentence for each source. Specify whether it detects a recorded signal, classifies an event, forecasts an aggregate outcome, or generates possible future sequences.
2. Trace one example from raw observations to model input and target. Include units, temporal resolution, spatial support and forecast horizon where applicable.
3. Identify when each input and label becomes available. For a foreshock/mainshock/aftershock label, investigate whether assigning the label uses later events. Distinguish a retrospectively defined label from a prospective prediction using information available at issuance.
4. Read the evaluation design: chronological or random splitting, geographic separation, baseline, metric and what the metric measures. Record **not reported in the source consulted** whenever a detail is unavailable; do not infer the protocol from a headline score.
5. Explain one useful connection to the tutorial and one reason the scores cannot be compared directly. Propose a common target and protocol that a fair comparison would require.

Submit a one-page comparison using this template:

| Item | Tutorial | Paper A | Paper B |
|:--|:--|:--|:--|
| Scientific question and task | | | |
| Input representation and available information | | | |
| Target, horizon and spatial support | | | |
| Model family | | | |
| Split and baseline | | | |
| Metric and interpretation | | | |
| Limitation or unresolved protocol detail | | | |

Add **150–200 words** explaining how a change in the target can matter as much as a change in the architecture. Cite each paper and state whether you consulted the full text or only its abstract. Label the Jara thesis and the manuscript under review separately if you use them as additional sources.

## Level 2 — Reproduce the demo, then extend one question

**Suggested time: 60–120 minutes, depending on Python familiarity and environment setup.** Use the [executable Transformer notebook](notebooks/transformer-demo.ipynb) and its [prepared outputs](notebooks/transformer-demo-solved.ipynb). The model is already defined and locally tested; this exercise does not ask you to implement attention from scratch. Participants can also complete the interpretation using saved outputs. The notebook imports TensorFlow even in prepared mode; if imports fail, open the prepared HTML page instead.

The pilot kept its architecture fixed before evaluation. It compared both neural models with catalogue-only inputs across seeds **7, 17 and 27**. The Transformer had higher losses in that experiment. Explaining the difference requires a new question and evidence, rather than attributing it to seismic complexity or declaring an architecture generally inferior.

### Start from the recorded comparison

1. Save a copy of the demo and use a separate output directory so the distributed results remain available.
2. Trace one example through its 30 × 3 input, learned representation and probability output. Explain the role of fixed sinusoidal position information and temporal averaging.
3. Read the existing results for every seed. Means in the comparison are averages of individual-fit metrics, not predictions from an ensemble. Check the differences in parameter count, completed epochs and fit time.
4. If reproducing the unchanged demo, record your environment and every result, including small numerical differences. A local success does not verify execution in a clean Colab runtime.
5. Before changing anything, write a hypothesis and choose **one** route below. Set `RUN_TRAINING = True` and `EVALUATE_TEST = False` for either extension. Execute **all cells in order**: the evaluation guard keeps the new run on validation while preserving the analysis and export steps. Leave the immutable `PILOT_SEEDS = [7, 17, 27]` unchanged.

### Route A — Does the comparison vary across more initializations?

Keep both architectures unchanged. In the first configuration cell, set `RUN_TRAINING = True`, `EVALUATE_TEST = False` and `SEEDS = [37, 47, 57]`; leave `REFERENCE_ARCHITECTURE = True`. These are three additional, predeclared runs for each model, separate from the immutable pilot seeds. Execute all cells, then report the original seeds 7, 17 and 27 alongside all additional runs; do not replace or select seeds because of their scores.

Summarize validation losses and paired Transformer-minus-LSTM differences for all six seeds. More seeds describe optimization variability more fully; they do not supply new earthquakes, independent test periods or a confidence interval for generalization.

### Route B — What role does explicit position information play?

In the copied notebook, set `RUN_TRAINING = True`, `EVALUATE_TEST = False`, `SEEDS = [7, 17, 27]` and `REFERENCE_ARCHITECTURE = False`. Set `EXTENSION_NOTE` to describe the single change, for example `"Remove fixed sinusoidal position encoding"`. In the copied model definition, omit only the line `x = SinusoidalPosition(name="day_position")(x)` and keep the rest of the model unchanged. Execute all cells in order. Retain the original position-aware Transformer and the LSTM as references.

Before fitting, state what information this change removes and why it might matter to this task. Compare validation predictions and losses for all three seeds. The result tests this particular position ablation; it does not establish that seismic order is irrelevant or identify the full cause of the original pilot's performance.

### Keep the rest of the experiment fixed

| Keep fixed | Required setting |
|:--|:--|
| Data and region | Frozen USGS catalogue; latitude −34 to −28, longitude −74 to −69 |
| Inputs | Previous 30 days; M ≥ 4.5; catalogue-only `log_count`, `max_magnitude_excess`, `has_event` |
| Target | At least one M ≥ 5 event in the next seven days, issued each Monday |
| Training and validation | 2001–2016 and 2017–2020, with the demo's chronological boundary exclusions |
| Preprocessing | The same windows and training-only normalization |
| Comparisons | Training-frequency and catalogue-only logistic baselines; original LSTM and Transformer |
| Training protocol | Same optimizer, learning rate, loss, batch size, maximum 20 epochs and early-stopping rule |

Do not also change the lookback, magnitude threshold, region, target or ETAS-inspired input. Those changes answer different questions. Keep all declared runs, including neutral or worse results. A common maximum training budget does not imply equal completed epochs, parameters or computing cost.

### Evaluate without turning the published test into a tuning set

Use validation Brier score and log loss, alongside a calibration plot with **common fixed bins 0, 0.1, …, 1 and counts for each model and seed**. Keep empty bins visible in the count table. Do not pool predictions across seeds and treat them as additional independent weeks.

The 2021–2025 test results are already available in the course and the pilot. Do not use them to choose an extension, seed or hyperparameter, and do not present a new analysis of that period as an untouched test. Any later evaluation on it must be labelled **exploratory retrospective evaluation on a previously inspected test period**. A confirmatory follow-up needs a genuinely untouched evaluation period and a protocol fixed before examining its outcomes.

The frozen catalogue also preserves the **revised retrospective** limitation: historical availability of individual event revisions remains unverified. Attention weights do not by themselves identify causal seismic mechanisms.

### Deliverables

| Deliverable | What it must contain |
|:--|:--|
| Reproducible copy or annotated prepared results | Hypothesis, chosen route, fixed settings, environment and data provenance |
| Validation table | Model/variant, every seed, n, positive weeks, Brier, log loss, parameters, epochs and fit time |
| One diagnostic | Common-bin calibration with counts or probability-versus-time plot with observed weeks |
| Short interpretation | 200–300 words separating observations, hypotheses, seed variability, test exposure and what remains unresolved |

Explain what the chosen experiment says about the **relationship between information, representation and task**. A small difference or stronger simple baseline can still be informative. The exercise does not rank LSTMs and Transformers across seismological tasks or establish an operational earthquake-warning system.
