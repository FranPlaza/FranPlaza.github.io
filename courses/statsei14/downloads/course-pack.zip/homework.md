
The live session follows the construction, training and evaluation of an LSTM and then a Transformer on the same regional catalogue history. Each model runs once with seed 7. During the laboratory, use the complete [temporal notebook](notebooks/linear/temporal.ipynb), its [prepared outputs](https://franplaza.github.io/courses/statsei14/tutorials/temporal.html), or the spatial tutorials at your own pace. Download the prepared notebooks or reconstruct the same cells in a blank Colab.

[Return to the practical](https://franplaza.github.io/courses/statsei14/practical.html) · [References and source links](https://franplaza.github.io/courses/statsei14/references.html)

## Read the task before the architecture

**Suggested time: 45–60 minutes. No training required.** Start with the current temporal guide's validation table and calibration outputs. State one supported observation and one possible explanation that those results cannot establish. Then compare the tutorial with two papers: a forecasting study (RECAST or Farfán et al.) and a detection/classification study (ConvNetQuake or Delgado et al.). Use the [references page](https://franplaza.github.io/courses/statsei14/references.html).

For each source, identify the scientific question, one input example, the target and when the information becomes available. Distinguish a retrospectively assigned foreshock/mainshock/aftershock label from prospective forecasting. Record **not reported in the source consulted** when a protocol detail is unavailable.

::: {.table-responsive}

| Item | Tutorial | Paper A | Paper B |
|:--|:--|:--|:--|
| Scientific question and task | | | |
| Input representation and available information | | | |
| Target, horizon and spatial support | | | |
| Model family | | | |
| Split, baseline and evaluation metric | | | |
| Limitation or unresolved detail | | | |

:::

Submit a one-page comparison and 150–200 words explaining why scores from different tasks cannot be ranked directly. Cite each paper and identify whether you consulted the full text or abstract. Keep the Jara thesis and the manuscript under review distinct if you include them.

## Compare architectures and examine repeated fits

**Suggested time: 60–120 minutes, depending on environment and Python familiarity.** Complete the optional MLP and CNN1D sections of the temporal notebook. Each model places its construction, training and evaluation together and uses seed 7. Then open the separate [three-seed comparison](https://franplaza.github.io/courses/statsei14/tutorials/temporal-comparison.html) or its [notebook](notebooks/comparison/temporal.ipynb) to examine seeds 7, 17 and 27.

1. Trace one 30 × 3 input through each model. Identify fixed lag positions in the MLP, a shared temporal filter in CNN1D, recurrent state in the LSTM, and learned positions plus attention in the Transformer.
2. Identify the model definition, `compile`, `fit`, `predict` and score calculation. Explain what `fit()` changes and which decisions the researcher fixed beforehand. Compare parameter counts and completed epochs as context for the losses.
3. Read Brier, log loss and calibration alongside the simple references. Separate the seed-7 result from the repeated comparison. In the latter, mean losses summarize individually scored fits; they are not the loss of an ensemble prediction.
4. Record your software versions and hardware, and note numerical differences from the supplied results. See [Environment and setup](https://franplaza.github.io/courses/statsei14/environment.html).

## Sensitivity to recurrent-state size: 8, 16 and 32 units

The network learns weights and biases. The recurrent-state size is a setting we choose before fitting. The 16-unit LSTM is a compact starting configuration; no search in this tutorial establishes it as optimal.

1. Declare the candidates **8, 16 and 32 units** before fitting. Change only the number in `keras.layers.LSTM(16)` in a separate copy of the temporal notebook.
2. Keep the three channels, 30-day history, target, region, chronological partitions, training-only scaling, Adam learning rate 0.001, batch size 64, maximum 20 epochs and patience 3 fixed. Keep `restore_best_weights=True` and `shuffle=False`.
3. Declare **validation log loss** as the primary comparison; also report Brier score, calibration with bin counts, parameter count and completed epochs. Begin with seed 7 to follow the procedure, then repeat **every candidate** with seeds 7, 17 and 27.
4. Retain all results. Assess whether any change persists across these initializations, and distinguish increased capacity from an improvement in the stated criterion.

The seven-day horizon and M ≥ 5 threshold define the scientific target. Changing them studies a different outcome. Changing the seed studies another training realization; it does not create new earthquake observations.

Validation is used for early stopping and for comparing candidates. The selected score is therefore development evidence. A subsequent independent assessment requires data that did not influence these choices and a selection procedure that respects chronological order. The already inspected 2021–2025 period cannot serve as a new untouched test.

## Choose one controlled extension

Write the hypothesis and the single proposed change before fitting. Keep an unchanged copy of the tutorial and write new outputs to a separate directory. Use training and validation only; retain every declared run, including neutral or worse results.

::: {.table-responsive}

| Route | One question | What to keep fixed |
|:--|:--|:--|
| Temporal representation | Does a different history length change the LSTM comparison? | Target, region, training/validation boundaries, seeds and baselines; rebuild windows and training-only scaling consistently |
| ETAS-inspired channel | Does adding the illustrative activity score help the same LSTM? | Catalogue channels, history, target and evaluation; document added parameters and do not mix this with an architecture change |
| Transformer positions | What changes when learned positional information is removed? | Remaining layers, data, optimizer, seeds and evaluation; report the resulting capacity change |
| Maps | Where are positive cell labels scarce, and how does this affect calibration? | Existing six-cell geometry and target; begin with prepared predictions before proposing a new grid |
| Graphs | Does rook adjacency differ from identity adjacency in this implementation? | Same six cells, node inputs, architecture, seeds and origins |

:::

The [map](https://franplaza.github.io/courses/statsei14/tutorials/maps.html) and [graph](https://franplaza.github.io/courses/statsei14/tutorials/graphs.html) tutorials predict the same six marginal probabilities. Their scores concern per-cell targets and should not be ranked against regional occurrence scores. Geographic adjacency does not establish physical triggering. The [ETAS-inspired feature experiment](https://franplaza.github.io/courses/statsei14/practical-reference.html) documents the illustrative ETAS-inspired score; it is not a fitted ETAS rate.

## Evaluate and report the extension

Use Brier and log loss, plus calibration with common bins and counts for each model and seed. For a repeated extension, declare seeds 7, 17 and 27 before running it and retain every result. A single-seed walkthrough cannot establish initialization stability. Do not treat multiple seeds as additional independent earthquake weeks. Validation also supports early stopping, so these comparisons remain development evidence.

::: {.table-responsive}

| Deliverable | Contents |
|:--|:--|
| Reproducible copy or annotated prepared outputs | Hypothesis, one change, fixed settings, environment and data provenance |
| Validation table | Model, every seed, sample size, positive labels, Brier, log loss, parameters, epochs and fit time |
| Diagnostic | Calibration with counts or predicted probabilities over time beside observed labels |
| Interpretation | 200–300 words separating observations, hypotheses, seed variability and unresolved limitations |

:::

The 2021–2025 test was inspected in earlier course work. Do not use it to select a change or present it as untouched evidence. A confirmatory follow-up requires a new evaluation period and a protocol fixed before examining its outcomes. Revised catalogue records also do not establish what was available at historical forecast times.

For an input experiment, use the [ETAS-inspired feature activity](https://franplaza.github.io/courses/statsei14/practical-reference.html). Keep the feature set, target and evaluation protocol explicit when interpreting any comparison.
