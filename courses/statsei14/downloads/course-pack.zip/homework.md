
The live session follows the construction, training and evaluation of an LSTM and then a Transformer on the same regional catalogue history. Each model runs once with seed 7. During the laboratory, use the complete [temporal notebook](downloads/tutorials/temporal.ipynb), its [prepared outputs](tutorials/temporal.qmd), or the spatial tutorials at your own pace. Download the prepared notebooks or reconstruct the same cells in a blank Colab.

[Return to the practical](https://franplaza.github.io/courses/statsei14/practical.html) · [References and source links](https://franplaza.github.io/courses/statsei14/references.html)

## Read the task before the architecture

**Suggested time: 45–60 minutes. No training required.** Start with the current temporal guide's validation table and calibration outputs. State one supported observation and one possible explanation that those results cannot establish. Then compare the tutorial with two papers: a forecasting study (RECAST or Farfán et al.) and a detection/classification study (ConvNetQuake or Delgado et al.). Use the [references page](https://franplaza.github.io/courses/statsei14/references.html).

For each source, identify the scientific question, one input example, the target and when the information becomes available. Distinguish a retrospectively assigned foreshock/mainshock/aftershock label from prospective forecasting. Record **not reported in the source consulted** when a protocol detail is unavailable.

::: {.table-responsive}

| Item | Tutorial | Paper A | Paper B |
|:--|:--|:--|:--|
| Scientific question and task | | | |
| Input representation and available information | | | |
| Target, horizon and spatial support | | | |
| Model family | | | |
| Split, baseline and evaluation metric | | | |
| Limitation or unresolved detail | | | |

:::

Submit a one-page comparison and 150–200 words explaining why scores from different tasks cannot be ranked directly. Cite each paper and identify whether you consulted the full text or abstract. Keep the Jara thesis and the manuscript under review distinct if you include them.

## Complete the linear walkthrough and examine repeated fits

**Suggested time: 60–120 minutes, depending on environment and Python familiarity.** Complete the optional MLP and CNN1D sections of the linear temporal notebook. Each model places its construction, training and evaluation together and uses seed 7. Then open the separate [three-seed comparison](tutorials/temporal-comparison.qmd) or its [notebook](downloads/comparison/temporal.ipynb) to examine seeds 7, 17 and 27.

1. Trace one 30 × 3 input through each model. Identify fixed lag positions in the MLP, a shared temporal filter in CNN1D, recurrent state in the LSTM, and learned positions plus attention in the Transformer.
2. Identify the model definition, `compile`, `fit`, `predict` and score calculation. Explain what `fit()` changes and which decisions the researcher fixed beforehand. Compare parameter counts and completed epochs as context for the losses.
3. Read Brier, log loss and calibration alongside the simple references. Separate the seed-7 result from the repeated comparison. In the latter, mean losses summarize individually scored fits; they are not the loss of an ensemble prediction.
4. Record your environment and differences from the prepared local results. Small numerical differences are possible. A local execution does not verify actual Colab execution.

## Choose one controlled extension

Write the hypothesis and the single proposed change before fitting. Keep an unchanged copy of the tutorial and write new outputs to a separate directory. Use training and validation only; retain every declared run, including neutral or worse results.

::: {.table-responsive}

| Route | One question | What to keep fixed |
|:--|:--|:--|
| Temporal representation | Does a different history length change the LSTM comparison? | Target, region, training/validation boundaries, seeds and baselines; rebuild windows and training-only scaling consistently |
| ETAS-inspired channel | Does adding the illustrative activity score help the same LSTM? | Catalogue channels, history, target and evaluation; document added parameters and do not mix this with an architecture change |
| Transformer positions | What changes when learned positional information is removed? | Remaining layers, data, optimizer, seeds and evaluation; report the resulting capacity change |
| Maps | Where are positive cell labels scarce, and how does this affect calibration? | Existing six-cell geometry and target; begin with prepared predictions before proposing a new grid |
| Graphs | Does rook adjacency differ from identity adjacency in this implementation? | Same six cells, node inputs, architecture, seeds and origins |

:::

The [map](tutorials/maps.qmd) and [graph](tutorials/graphs.qmd) tutorials predict the same six marginal probabilities. Their scores concern per-cell targets and should not be ranked against regional occurrence scores. Geographic adjacency does not establish physical triggering. The [original feature experiment](practical-reference.qmd) documents the illustrative ETAS-inspired score; it is not a fitted ETAS rate.

## Evaluate and report the extension

Use Brier and log loss, plus calibration with common bins and counts for each model and seed. For a repeated extension, declare seeds 7, 17 and 27 before running it and retain every result. A single-seed walkthrough cannot establish initialization stability. Do not treat multiple seeds as additional independent earthquake weeks. Validation also supports early stopping, so these comparisons remain development evidence.

::: {.table-responsive}

| Deliverable | Contents |
|:--|:--|
| Reproducible copy or annotated prepared outputs | Hypothesis, one change, fixed settings, environment and data provenance |
| Validation table | Model, every seed, sample size, positive labels, Brier, log loss, parameters, epochs and fit time |
| Diagnostic | Calibration with counts or predicted probabilities over time beside observed labels |
| Interpretation | 200–300 words separating observations, hypotheses, seed variability and unresolved limitations |

:::

The 2021–2025 test was inspected in earlier course work. Do not use it to select a change or present it as untouched evidence. A confirmatory follow-up requires a new evaluation period and a protocol fixed before examining its outcomes. Revised catalogue records also do not establish what was available at historical forecast times.

The [earlier LSTM/ETAS exercise and Transformer pilot](practical-reference.qmd) remain separate reference materials. Their fixed sinusoidal positions, logistic summaries and test results belong to that earlier experiment, not to the current learned-position tutorial.
