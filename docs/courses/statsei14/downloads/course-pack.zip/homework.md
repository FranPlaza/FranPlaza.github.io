# Further exploration

These resources are for conference participants who would like to explore the examples after the session or adapt them to their own research. All routes are optional. The prepared outputs provide a starting point for discussion without training a model.

The [temporal notebook](notebooks/linear/temporal.ipynb) and its [web guide with example outputs](https://franplaza.github.io/courses/statsei14/tutorials/temporal.html) contain the LSTM and Transformer comparison, followed by MLP and CNN1D extensions. The map and graph tutorials offer spatial examples. Graph + LSTM can be introduced through its input and output during the session and continued here using the complete notebook. You can download the prepared notebooks or reconstruct the same cells in Colab.

[Return to the practical](https://franplaza.github.io/courses/statsei14/practical.html) · [References and source links](https://franplaza.github.io/courses/statsei14/references.html)

## Questions to take into your research

- Which aspects of seismic activity does the input representation retain, and which does it leave out?
- What information would actually be available when issuing a forecast?
- Does a model improve on a simple reference, and does that conclusion depend on the metric or initialization?
- Which additional data or evaluation period would support a stronger conclusion?

The validation table and calibration outputs in the temporal guide illustrate these questions. An observed difference between models can suggest a hypothesis; it does not by itself identify the reason for that difference.

## Two short research examples

The [research examples](https://franplaza.github.io/courses/statsei14/tutorials/research-examples.html) connect the case studies to explicit inputs and targets. Inspect how daily maps become one temporal window, then how an aftershock sequence becomes a threshold label. These are short data transformations with prepared outputs, rather than another training exercise.

## Read across scientific tasks

The [references](https://franplaza.github.io/courses/statsei14/references.html) include forecasting studies such as RECAST and Farfán et al., and detection or classification studies such as ConvNetQuake and Delgado et al. A useful way to connect them to your own work is to compare their questions, representations and evidence.

::: {.table-responsive}

| Aspect | Question for reading a study |
|:--|:--|
| Scientific task | What question does the model answer? |
| Input and information availability | What is one input example, and when are its measurements available? |
| Target | What is predicted, over which horizon and spatial support? |
| Evaluation | Which splits, reference forecasts and metrics support the claim? |
| Limits | What is unresolved or not reported in the source consulted? |

:::

A retrospectively assigned foreshock/mainshock/aftershock label differs from a prospective forecasting target. Scores for different tasks cannot be ranked directly. When reusing a claim, cite the source and distinguish evidence available in its full text from information in an abstract. The Jara thesis and the manuscript under review are separate sources.

## Explore the supplied models

The optional MLP and CNN1D sections of the temporal notebook follow the LSTM and Transformer. They process the same 30 × 3 input using different assumptions: fixed lag positions in an MLP, shared temporal filters in CNN1D, recurrent state in an LSTM, and learned positions plus attention in the Transformer.

Each model places its definition, `compile`, `fit`, `predict` and evaluation together. This makes it possible to follow what training changes and which settings the researcher chooses beforehand. Parameter counts and completed epochs provide context for the losses.

The guided examples use **seed 7**. The separate [three-seed comparison](https://franplaza.github.io/courses/statsei14/tutorials/temporal-comparison.html), also available as a [notebook](notebooks/comparison/temporal.ipynb), explores seeds **7, 17 and 27**. Read Brier score, log loss and calibration alongside the simple references. Mean losses summarize individually scored fits; they are not the loss of an ensemble prediction. A single run cannot establish stability across initializations.

See [Environment and setup](https://franplaza.github.io/courses/statsei14/environment.html) for software versions and the context of the prepared results. If you rerun a notebook, recording your versions and hardware helps interpret numerical differences.

## One optional experiment: 8, 16 and 32 LSTM units

The network learns weights and biases. Its recurrent-state size is a setting chosen before fitting. The 16-unit LSTM is a compact starting configuration; this tutorial does not establish it as optimal.

If model capacity is relevant to your research question, a controlled comparison could use the following protocol:

1. Declare **8, 16 and 32 units** before fitting. Change only the number in `keras.layers.LSTM(16)` in a separate copy of the temporal notebook.
2. Keep the three channels, 30-day history, target, region, chronological partitions, training-only scaling, Adam learning rate 0.001, batch size 64, maximum 20 epochs and patience 3 fixed. Keep `restore_best_weights=True` and `shuffle=False`.
3. Declare **validation log loss** as the primary comparison; also inspect Brier score, calibration with bin counts, parameter count and completed epochs. Seed 7 provides an initial walkthrough; assessing initialization sensitivity requires repeating **every candidate** with seeds **7, 17 and 27**.
4. Retain every run, including neutral or worse results. Examine whether a difference persists across these initializations, rather than selecting the best-looking seed.

The seven-day horizon and M ≥ 5 threshold define the scientific target. Changing them studies a different outcome. Changing the seed studies another training realization; it does not create new earthquake observations.

Validation controls early stopping and the comparison of candidates. A selected validation score remains development evidence. Independent assessment requires data that did not influence these choices and a selection procedure that respects chronological order.

## Continue with Graph + LSTM

The [graph tutorial](https://franplaza.github.io/courses/statsei14/tutorials/graphs.html) starts with a study-area map and overlays the numbered six-cell grid before representing those cells as nodes. Follow the sequence at your own pace: inspect the cells and their neighbours, read one 30 × 6 × 3 input, then trace neighbour aggregation and the LSTM to six weekly occurrence probabilities. The notebook and its example outputs are complete even if the live discussion stops at the representation.

Compare the graph with the [map tutorial](https://franplaza.github.io/courses/statsei14/tutorials/maps.html) using the same cells and targets. The six probabilities describe separate cell outcomes and need not sum to one. They differ from the six mutually exclusive macrozone classes in Nicolis et al. (2021).

## Other questions to explore

The following routes can help connect the examples to a question of your own. Each separates one modelling decision from the rest of the experiment.

::: {.table-responsive}

| Route | Possible question | What to keep fixed |
|:--|:--|:--|
| Temporal representation | Does a different history length change the LSTM comparison? | Target, region, training/validation boundaries, seeds and baselines; rebuild windows and training-only scaling consistently |
| ETAS-inspired channel | Does adding the illustrative activity score help the same LSTM? | Catalogue channels, history, target and evaluation; document added parameters and keep this separate from an architecture change |
| Transformer positions | What changes when learned positional information is removed? | Remaining layers, data, optimizer, seeds and evaluation; account for the resulting capacity change |
| Maps | Where are positive cell labels scarce, and how does this affect calibration? | Existing six-cell geometry and target; prepared predictions provide a starting point before proposing a new grid |
| Graphs | Does rook adjacency differ from identity adjacency in this implementation? | Same six cells, node inputs, architecture, seeds and origins |

:::

The [map](https://franplaza.github.io/courses/statsei14/tutorials/maps.html) and [graph](https://franplaza.github.io/courses/statsei14/tutorials/graphs.html) tutorials predict the same six marginal probabilities. Their per-cell scores should not be ranked against regional occurrence scores. Geographic adjacency does not establish physical triggering. The [ETAS-inspired feature experiment](https://franplaza.github.io/courses/statsei14/practical-reference.html) documents an illustrative activity score; it is not a fitted ETAS rate.

## Keep an exploration interpretable

For any experiment you choose to pursue, define the hypothesis and proposed change before fitting. Keep an unchanged reference and save new outputs separately. A reproducible record includes the model settings, data provenance, software environment and every declared run.

Brier score, log loss and calibration describe complementary aspects of probability forecasts. Common calibration bins and their counts help compare models and seeds. Retaining all seeds distinguishes a recurring difference from a favourable individual fit; those seeds are not additional independent earthquake weeks.

Use training and validation for these explorations. The **2021–2025 test period was inspected in earlier work** and cannot serve as a new untouched test for selecting a configuration. A confirmatory follow-up needs a new evaluation period and a protocol fixed before examining its outcomes. Revised catalogue records also do not establish what was available at historical forecast times.
