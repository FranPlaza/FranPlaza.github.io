# Frozen USGS teaching catalogue

`frozen/usgs_chile_2000_2025.csv` is a snapshot of USGS ComCat preferred records.
`provenance.json` records query URLs, retrieval UTC, SHA-256 and filters.
The download covers 2000-01-01 inclusive to 2026-01-01 exclusive, latitude
[-34,-28], longitude [-74,-69], event type earthquake, catalogue magnitude >= 3.
Annual requests avoid the 20,000-record response limit; duplicated boundary ids
are removed, keeping the latest updated record.

The notebook retains M >= 4.5 for inputs and defines the target with >= 5.0.
The lower download threshold is for training-period coverage diagnostics.
Do not interpret either threshold as an estimated uniform completeness magnitude.

Keep `magType`, `updated`, `status` and the original event id. Magnitudes are
not all Mw. Magnitude or location revisions can change regional membership and
threshold exceedance.

## Availability limitation
This is not an as-of archive. Preferred final records do not contain every
historical version or first publication time. Filtering final updated timestamps
does not reconstruct the original observable catalogue. The primary exercise
therefore establishes event-time separation, not operational historical replay.

A strict availability-aware dataset would need version_id, available_at,
origin_time, magnitude/type, location and withdrawal information, with a documented
label-adjudication delay. No such archive is represented as verified in this release.

## Interpretation
An empty recorded interval is an absence of qualifying catalogue records under the
query, not proof that no smaller or undetected earthquakes occurred.
No retrospective declustering is used. The fixed box omits triggering events outside
its boundaries; transfer to other regions needs new data and validation.

Source: https://earthquake.usgs.gov/fdsnws/event/1/
