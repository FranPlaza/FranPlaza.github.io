# Notebook course pack
Start the guided session with notebooks/linear/temporal.ipynb. Begin with the study-area map and follow the core LSTM example. The Transformer comparison can use prepared outputs. notebooks/research-examples.ipynb illustrates two input/target transformations using constructed values, without training. Optional questions and resources are in [Further exploration](homework.md). notebooks/linear/maps.ipynb and graphs.ipynb are spatial extensions. notebooks/comparison contains the three-seed initialization comparisons.

Extract this full pack before use. The workshop notebook studies an ETAS-inspired input feature; transformer-demo uses fixed sinusoidal positions. Those two notebooks request a data/course ZIP when run in Colab. Their models and reported results define separate experiments.

For a local environment: python -m pip install -r requirements.txt. Open a notebook in Jupyter and run cells in order. For setup, software versions and the context of supplied outputs, see https://franplaza.github.io/courses/statsei14/environment.html

This pack includes data, configuration, notebooks, result files, the instructor guide, Further exploration and references. Choose tutorials-pack.zip for the smaller guided-session download, or comparison-pack.zip for initialization sensitivity.
