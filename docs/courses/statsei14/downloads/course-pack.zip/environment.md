
## Open a notebook

Download the [temporal notebook](notebooks/linear/temporal.ipynb), open [Google Colab](https://colab.research.google.com/), choose **File > Upload notebook**, and select the file. A Python CPU runtime is sufficient for these small models. Run the cells from the beginning in order. The [web guide](https://franplaza.github.io/courses/statsei14/tutorials/temporal.html) provides explanations and example outputs.

The first preparation cells download a frozen data pack pinned to a Git commit and verify its SHA-256. To work locally, extract the [tutorial pack](https://franplaza.github.io/courses/statsei14/downloads/tutorials-pack.zip) and keep `statsei14-data-pack.zip` beside the notebooks. With the required libraries installed, the notebooks reuse that file without downloading it.

If imports fail in Colab, run this in a separate cell, restart the runtime, and begin again:

```python
%pip install tensorflow==2.19.1 keras==3.15.1 pandas scikit-learn matplotlib
```

## Environment of the example results

The supplied model outputs come from fresh Windows CPU runs on **7 October 2026**. The study-area maps, numbered spatial grids and individual LSTM learning-curve display were checked separately on **11 October 2026**, using the same frozen data and recorded model outputs. The LSTM calibration cell now appears before the core stopping point. The original scientific cells and their outputs are preserved, including that relocated calibration cell; the expanded notebooks have not been rerun end to end. A complete execution in an actual Colab session has **not been verified**. Hardware and software versions can affect runtime and numerical results. Record both when comparing your run with the supplied outputs.

| Component | Recorded version |
|:--|:--|
| Python | 3.12.14 |
| TensorFlow | 2.19.1 |
| Keras | 3.15.1 |
| NumPy | 2.1.3 |
| pandas | 2.3.3 |

The guided examples use **seed 7**, one fit per neural model. The initialization comparisons use **7, 17 and 27** and report every run. A shared seed does not imply identical weights across architectures.

The web pages show numerical summaries, figures and relevant diagnostic messages. Complete execution streams, including library warnings and run-specific file paths, remain in the downloadable notebooks with outputs. The [seed-7 result archive](https://franplaza.github.io/courses/statsei14/downloads/linear-results.zip) and [three-seed result archive](https://franplaza.github.io/courses/statsei14/downloads/tutorial-results.zip) include predictions and run information.

### The prepared LSTM learning curve

The individual LSTM curve uses losses recorded in the original training log, rounded there to four decimals. It is a reconstruction of that recorded run, not a new fit. When you run the notebook, the plotting cell reads the full-precision values in `history_lstm.history`. The original comparative curve remains available with the optional Transformer material. In the prepared LSTM run, validation loss was lowest at epoch 20, the allowed maximum; early stopping did not stop it before that limit.

The web calibration figure uses the same saved validation predictions and binning, with extra space for the count labels. The original notebook output is retained.

### Research examples and source figures

The [two research examples](https://franplaza.github.io/courses/statsei14/tutorials/research-examples.html) demonstrate input-window and label construction without fitting another model. Their source and any illustrative values are stated beside each example. Published figure extracts retain their source attribution; example transformations and original article evaluations have separate roles.

Frozen data-pack SHA-256:

```text
0ee5d4d71aafa19023fdb1ee6f289a11e7fd7f4ed88ad7a91032ca24505d10a2
```

## If execution is interrupted

Restart from the first cell to reconstruct the variables in order. Download your generated result files before closing a temporary Colab session; the temporal notebook writes CSV files to `outputs_temporal`. If setup or fitting stalls during the tutorial, continue the discussion with the supplied outputs.

See the [practical protocol](https://franplaza.github.io/courses/statsei14/practical.html#what-stays-fixed) for chronological partitions and interpretation limits. The frozen revised catalogue does not reconstruct historical catalogue versions.
