
## Open a notebook

Download the [temporal notebook](notebooks/linear/temporal.ipynb), open [Google Colab](https://colab.research.google.com/), choose **File > Upload notebook**, and select the file. A Python CPU runtime is sufficient for these small models. Run the cells from the beginning in order. The [web guide](https://franplaza.github.io/courses/statsei14/tutorials/temporal.html) provides explanations and example outputs.

The first preparation cells download a frozen data pack pinned to a Git commit and verify its SHA-256. To work locally, extract the [tutorial pack](downloads/tutorials-pack.zip) and keep `statsei14-data-pack.zip` beside the notebooks. With the required libraries installed, the notebooks reuse that file without downloading it.

If imports fail in Colab, run this in a separate cell, restart the runtime, and begin again:

```python
%pip install tensorflow==2.19.1 pandas scikit-learn matplotlib
```

## Environment of the example results

The supplied guided notebooks were executed in fresh Windows CPU kernels on **7 October 2026**. A complete execution in an actual Colab session has **not been verified**. Hardware and software versions can affect runtime and numerical results. Record both when comparing your run with the supplied outputs.

| Component | Recorded version |
|:--|:--|
| Python | 3.12.14 |
| TensorFlow | 2.19.1 |
| Keras | 3.15.1 |
| NumPy | 2.1.3 |
| pandas | 2.3.3 |

The guided examples use **seed 7**, one fit per neural model. The initialization comparisons use **7, 17 and 27** and report every run. A shared seed does not imply identical weights across architectures.

The web pages show numerical summaries, figures and relevant diagnostic messages. Complete execution streams, including library warnings and run-specific file paths, remain in the downloadable notebooks with outputs. The [seed-7 result archive](downloads/linear-results.zip) and [three-seed result archive](downloads/tutorial-results.zip) include predictions and run information.

Frozen data-pack SHA-256:

```text
0ee5d4d71aafa19023fdb1ee6f289a11e7fd7f4ed88ad7a91032ca24505d10a2
```

## If execution is interrupted

Restart from the first cell to reconstruct the variables in order. Save the generated result archive before closing a temporary Colab session. If setup or fitting stalls during the tutorial, continue the discussion with the supplied outputs.

See the [practical protocol](https://franplaza.github.io/courses/statsei14/practical.html#what-stays-fixed) for chronological partitions and interpretation limits. The frozen revised catalogue does not reconstruct historical catalogue versions.
