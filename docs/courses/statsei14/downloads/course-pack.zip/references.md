
## Course sources

- [STATSEI14 official programme](https://www.statsei14.cl/). Consulted 5 October 2026. Tutorial: 13 October, 11:30–12:30, after Jiancang Zhuang and the break.
- [Francisco Plaza-Vega: Deep Learning course](https://franplaza.github.io/courses/deep_learning/). Background on representations, losses and architectures.
- [Quarto and GitHub Pages mini-course](https://franplaza.github.io/courses/quarto_github_pages/index.html). Optional material on reproducible publication.

## Deep learning in seismology: different tasks

These primary studies provide context for the opening discussion. Their inputs, targets and evaluation settings differ; their reported scores do not form a performance ranking for this tutorial.

**Perol, T., Gharbi, M., and Denolle, M. (2018).** Convolutional neural network for earthquake detection and location. *Science Advances*, 4(2), e1700578. [DOI](https://doi.org/10.1126/sciadv.1700578) · [Open article](https://pmc.ncbi.nlm.nih.gov/articles/PMC5817932/).

ConvNetQuake takes three-component waveform windows and classifies noise or an earthquake's geographic cluster. This is detection and location from recorded signals; the practical instead forecasts occurrence from a catalogue history.

**Dascher-Cousineau, K., Shchur, O., Brodsky, E. E., and Günnemann, S. (2023).** Using Deep Learning for Flexible and Scalable Earthquake Forecasting. *Geophysical Research Letters*, 50, e2023GL103909. [DOI and article](https://doi.org/10.1029/2023GL103909).

RECAST uses a recurrent neural temporal point process to map past event times and magnitudes to a distribution for the next event time. Simulated catalogue continuations support probabilistic forecasts. Its temporal ETAS comparison connects flexible learning with an explicit statistical benchmark; it does not establish superiority over every ETAS formulation.

## Transformer context and further reading

The closing demonstration compares a compact Transformer with an LSTM on the same weekly occurrence task. The [executed demo](notebooks/transformer-demo-solved.ipynb) and [participant notebook](notebooks/transformer-demo.ipynb) make the architecture and its local results available. The [homework](https://franplaza.github.io/courses/statsei14/homework.html) extends this comparison after the session. This is a new teaching experiment, distinct from the studies below.

**Delgado, L., Peralta, B., Nicolis, O., and Díaz, M. (2025).** Integrating spatio-temporal density-based clustering and neural networks for earthquake classification. *Expert Systems with Applications*, 277, 127186. [DOI](https://doi.org/10.1016/j.eswa.2025.127186) · [Institutional record and abstract](https://researchers.unab.cl/en/publications/integrating-spatio-temporal-density-based-clustering-and-neural-n/).

The study combines spatio-temporal clustering, event labels and LSTM/Transformer classification. Its labels distinguish foreshocks, mainshocks and aftershocks. Classifying such labels is a different target from a probability of an event in a future week. Establishing what information is available when a label is assigned is part of the homework reading.

**Farfán, Y., Nicolis, O., and Peralta, B. (2025).** Earthquake Forecasting using Temporal Transformers on Spatial Grids in Chile. *2025 IEEE CHILEAN Conference on Electrical, Electronics Engineering, Information and Communication Technologies (CHILECON).* [DOI](https://doi.org/10.1109/CHILECON66915.2025.11476035) · [Institutional record and abstract](https://researchers.unab.cl/en/publications/earthquake-forecasting-using-temporal-transformers-on-spatial-gri/).

This conference contribution compares temporal architectures using daily 4 × 4 spatial grids from Chilean seismic data. The abstract explicitly identifies the coarse binary representation and absence of geophysical information as limitations. It motivates a discussion of representation and attention, rather than a direct score comparison with this practical.

The two institutional abstracts establish the scope of these examples. Consult the full papers for protocol details; an abstract alone does not establish the timing of feature availability or the absence of leakage.

## Published case study

**Nicolis, O., Plaza, F., and Salas, R. (2021).** Prediction of intensity and location of seismic events using deep learning. *Spatial Statistics*, 42, 100442. [DOI](https://doi.org/10.1016/j.spasta.2020.100442).

The LSTM predicts the next day's maximum of an ETAS-derived intensity representation. The CNN classifies the macrozone of the next maximum. These are different targets from the weekly binary occurrence task in this tutorial. The published catalogue is from Chile's National Seismological Center, not the USGS catalogue used in the practical.

## Thesis and manuscript under review

**Jara Muñoz, I. (2025).** *Generación de secuencias de réplicas sísmicas a partir de la ocurrencia de terremotos en Chile utilizando redes adversariales generativas.* Thesis. Supervisor: Francisco Plaza Vega.

**Plaza-Vega, F., Jara, I., Nicolis, O., and Salinas, V. (2026).** *From Sequence Generation to Sparse-Target Learning for Aftershock Risk Ranking in the Pacific Ring of Fire.* Manuscript under review (revised April 2026).

The thesis and the revision are separate sources. Their scores and conclusions must not be interchanged. The manuscript under review compares generation with aggregate targets; its classification results from Random Forest and Gradient Boosting are not neural-network results. ETAS–GAN integration is proposed future work, outside its empirical experiments.

The sequence representation uses 224 intervals of 90 minutes. A maximum magnitude per interval loses event multiplicity; occupied intervals cannot be reported as total earthquake counts. A value of 2.5 encodes absence in that study.

## Four historical milestones

- Rumelhart, D. E., Hinton, G. E., and Williams, R. J. (1986). [Learning representations by back-propagating errors](https://www.nature.com/articles/323533a0).
- Hochreiter, S., and Schmidhuber, J. (1997). [Long Short-Term Memory](https://direct.mit.edu/neco/article/9/8/1735/6109/Long-Short-Term-Memory).
- Krizhevsky, A., Sutskever, I., and Hinton, G. E. (2012). [ImageNet Classification with Deep Convolutional Neural Networks](https://papers.nips.cc/paper_files/paper/2012/hash/c399862d3b9d6b76c8436e924a68c45b-Abstract.html).
- Vaswani, A., et al. (2017). [Attention Is All You Need](https://arxiv.org/abs/1706.03762).

For adversarial learning: Goodfellow, I., et al. (2014), [Generative Adversarial Nets](https://arxiv.org/abs/1406.2661).

## Data and software

- [USGS ComCat API](https://earthquake.usgs.gov/fdsnws/event/1/).
- [Versioning and preferred products in ComCat](https://earthquake.usgs.gov/data/catalog/products.php).
- [Why USGS updates magnitudes](https://www.usgs.gov/faqs/whywhen-does-usgs-update-magnitude-earthquake).
- [Keras LSTM documentation](https://keras.io/api/layers/recurrent_layers/lstm/).
- [Keras MultiHeadAttention documentation](https://keras.io/api/layers/attention_layers/multi_head_attention/).
- [Keras time-series Transformer example](https://keras.io/examples/timeseries/timeseries_classification_transformer/). Architectural background. The demo uses its own fixed small design, chronological partitions and positional encoding.
- [Quarto GitHub Pages publication](https://quarto.org/docs/publishing/github-pages.html).
- [Quarto execution controls](https://quarto.org/docs/projects/code-execution.html).
- [Grant McDermott's clean revealjs extension](https://github.com/grantmcdermott/quarto-revealjs-clean).

## Figure attribution

The published workflow and selected generative-study figures are author-provided research assets. Attribution appears in the slide notes and figure captions. Original plots in the practical are generated from the frozen USGS data.

The distribution package does not include the thesis, private manuscript PDFs or the publisher's article PDF. Research-figure copyrights remain with their respective rights holders.

## Map data

[Natural Earth, Admin 0 Countries, 1:50m](https://www.naturalearthdata.com/downloads/50m-cultural-vectors/50m-admin-0-countries-2/) supplies the coastlines and country outlines. A frozen regional subset and its provenance are included in data/geography, so the map renders offline.
